package com.ssafy.happyhouse.model;

public class UserDto {
	private String user_id;
	private String user_pwd;
	private String user_name;
	private String email;
	private String phone;

	public UserDto() {}

	public UserDto(String userid, String userpwd, String username, String email, String phone) {

		this.user_id = userid;
		this.user_pwd = userpwd;
		this.user_name = username;
		this.email = email;
		this.phone = phone;
	}

	public String getUserid() {
		return user_id;
	}


	public void setUserid(String userid) {
		this.user_id = userid;
	}


	public String getUserpwd() {
		return user_pwd;
	}


	public void setUserpwd(String userpwd) {
		this.user_pwd = userpwd;
	}


	public String getUsername() {
		return user_name;
	}


	public void setUsername(String username) {
		this.user_name = username;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Override
	public String toString() {
		return "UserDto [userid=" + user_id + ", userpwd=" + user_pwd + ", username=" + user_name + ", email=" + email
				+ ", phone=" + phone + "]";
	}
	
}
