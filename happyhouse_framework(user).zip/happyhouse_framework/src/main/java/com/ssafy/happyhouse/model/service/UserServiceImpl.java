package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.UserDto;
import com.ssafy.happyhouse.model.UserFavoriteDto;
import com.ssafy.happyhouse.model.mapper.UserMapper;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserMapper usermapper;
	
	@Override
	public UserDto selectOneUserById(String userid) throws Exception {
		return usermapper.selectOneUserById(userid);
	}

	@Override
	public List<UserDto> selectAll() throws Exception {
		return usermapper.selectAll();
	}
	
	@Override
	public void insert(UserDto user)  throws Exception{
		usermapper.insert(user);
		
	}

	@Override
	public void update(UserDto user)  throws Exception{
		usermapper.update(user);
		
	}

	@Override
	public void delete(String userid) throws Exception {
		usermapper.delete(userid);
		
	}
	
	@Override
	public List<UserFavoriteDto> selectFavorite(String userid) throws Exception {
		
		return usermapper.selectFavorite(userid);
	}
	
	@Override
	public String getdongcode(String dongname) throws Exception {
		
		return usermapper.getdongcode(dongname);
	}

	@Override
	public String getdongname(String dongCode)  throws Exception{
	
		return usermapper.getdongname(dongCode);
	}

	@Override
	public void insertFavorite(UserFavoriteDto dto) throws Exception {
		usermapper.insertFavorite(dto);
	}

	@Override
	public void deleteFavorite(UserFavoriteDto dto) throws Exception {
		usermapper.deleteFavorite(dto);
	}

	@Override
	public UserDto login(Map<String, String> map) throws Exception {
		return usermapper.login(map);
	}

	@Override
	public String getpwd(String userid, String username) throws Exception {
		return usermapper.getpwd(userid, username);
	}

	@Override
	public void deleteFavoriteAll(String userid) throws SQLException {
		usermapper.deleteFavoriteAll(userid);
	}
	
	




}
