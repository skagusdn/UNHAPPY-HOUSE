package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ssafy.happyhouse.model.UserDto;
import com.ssafy.happyhouse.model.UserFavoriteDto;

public interface UserService {
	public UserDto selectOneUserById(String userid)throws Exception;
	public List<UserDto> selectAll()throws Exception;
	public void insert(UserDto user)throws Exception;
	public void update(UserDto user)throws Exception;
	public void delete(String userid)throws Exception;
	public List<UserFavoriteDto> selectFavorite(String userid)throws Exception;
	public String getdongcode(String dongname)throws Exception;
	public String getdongname(String dongCode)throws Exception;
	public void insertFavorite(UserFavoriteDto dto)throws Exception;
	public void deleteFavorite(UserFavoriteDto dto)throws Exception;
	public UserDto login(Map<String, String> map) throws Exception;
	public String getpwd(String userid, String username)throws Exception;
	public void deleteFavoriteAll(String userid) throws SQLException;
}
