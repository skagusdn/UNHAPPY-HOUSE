package com.ssafy.happyhouse.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssafy.happyhouse.model.UserDto;
import com.ssafy.happyhouse.model.UserFavoriteDto;
import com.ssafy.happyhouse.model.service.UserService;


@Controller
@RequestMapping("/user")
public class UserController {
	
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	private UserService userService;
	

	@GetMapping("/register")
	public String register() {
		return "user/join";
	}
	
	@PostMapping("/register")	// 회원가입
	public String register(UserDto userDto, Model model) throws Exception {
		
		logger.debug("UserDto : {}",userDto);
		userService.insert(userDto);
		return "redirect:/user/login";
	}
	
	@GetMapping("/logout")  // 로그아웃
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	
	
	@GetMapping("/login")
	public String login() {
		return "user/login";
	}
	
	@PostMapping("/login")
	public String login(@RequestParam("userid") String userid, @RequestParam("userpwd") String userpwd,
			HttpSession session, Model model) throws Exception {
		
		UserDto userDto = userService.selectOneUserById(userid);
		System.out.println(userDto);
		
		if (userDto != null) {
			System.out.println(userid);
			userDto = userService.selectOneUserById(userid);
			System.out.println(userDto);
			session.setAttribute("userinfo", userDto);	
			return "redirect:/";
		} else {
			model.addAttribute("errorMsg", "아이디 혹은 비밀번호가 일치하지 않습니다.");
			System.out.println("로그인 실패");
			return "redirect:/";
		}
		
	}
	
	@GetMapping("/list")	// 전체 조회
	public String selectAll(Model model) throws Exception{
		List<UserDto> list = userService.selectAll();
		model.addAttribute("userList", list);
		
		return "user/list";
	}
	

	@GetMapping("/detail")	// 상세조회
	public String showDetails(HttpSession session) throws Exception {
		return "user/detail";
	}
	
	
	@ResponseBody
	@GetMapping("/findPwd") // 비밀번호 찾기
	public UserDto findPwd(@RequestParam("userid") String userid, @RequestParam("username") String username) throws Exception {
		UserDto user = userService.selectOneUserById(userid);
		logger.debug("UserDto : ",user);
		return user;
	}
	
	@GetMapping("/update")
	public String update() {
		return "user/update";
	}
	
	@PostMapping("/update")	// 회원정보수정
	public String update(@RequestParam("userpwd") String userpwd,
			@RequestParam("email") String email, @RequestParam("username") String username, @RequestParam("phone") String phone, HttpSession session) throws Exception {
		
		UserDto user1 = (UserDto)session.getAttribute("userinfo");
		UserDto user = new UserDto(user1.getUserid(),userpwd,username,email,phone);
		System.out.println(user);
		userService.update(user);
		return "redirect:/user/detail";
	}

	@RequestMapping("/delete") // 회원삭제
	public String delete(HttpSession session) throws Exception {
		UserDto user = (UserDto)session.getAttribute("userinfo");
		userService.deleteFavoriteAll(user.getUserid());
		userService.delete(user.getUserid());
		session.invalidate();
		return "redirect:/";
		
	}
	
	@RequestMapping("/getFavorite") // 관심지역 조회
	@ResponseBody
	public List<UserFavoriteDto> getFavorite (HttpSession session, Model model) throws Exception {
		String id = (String)session.getAttribute("userid");
		List<UserFavoriteDto> list = userService.selectFavorite(id);
		
		model.addAttribute("favoritelist", list);
		return list;
	}
	
	@RequestMapping("/deleteFavorite")  // 관심지역 삭제
	public String deleteFavorite(HttpSession session, @RequestParam("dongname") String dongname) throws Exception {
		String id = (String)session.getAttribute("userid");
		String dongcode = userService.getdongcode(dongname);
		UserFavoriteDto ufd = new UserFavoriteDto(id, dongcode);
		userService.deleteFavorite(ufd);
		logger.debug("UserFavoriteDto : ",ufd);
		return "redirect:/";
	}
	
	@PostMapping("/insertFavorite")  // 관심지역 등록
	public String insertFavorite(HttpSession session, @RequestParam("dongname") String dongname) throws Exception {
		String id = (String)session.getAttribute("userid");
		String dongcode = userService.getdongcode(dongname);
		UserFavoriteDto ufd = new UserFavoriteDto(id, dongcode);
		userService.insertFavorite(ufd);
		logger.debug("UserFavoriteDto : ",ufd);
		return "redirect:/";
	}
}
