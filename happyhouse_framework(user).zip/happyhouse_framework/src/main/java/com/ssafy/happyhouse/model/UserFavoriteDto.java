package com.ssafy.happyhouse.model;

public class UserFavoriteDto {
	private String userid;
	private String dongCode;
	
	
	public UserFavoriteDto() {}
	
	public UserFavoriteDto(String userid, String dongCode) {
		this.userid = userid;
		this.dongCode = dongCode;
	}
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String user_id) {
		this.userid = user_id;
	}
	public String getDongCode() {
		return dongCode;
	}
	public void setDongCode(String dongCode) {
		this.dongCode = dongCode;
	}
	
	

}
