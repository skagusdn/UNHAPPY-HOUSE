package com.ssafy.happyhouse.model.mapper;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.model.UserDto;
import com.ssafy.happyhouse.model.UserFavoriteDto;

@Mapper
public interface UserMapper {
	public UserDto selectOneUserById(String userid) throws SQLException;
	public List<UserDto> selectAll() throws SQLException;
	public void insert(UserDto user) throws SQLException;
	public void update(UserDto user) throws SQLException;
	public void delete(String userid) throws SQLException;
	public List<UserFavoriteDto> selectFavorite(String userid) throws SQLException;
	public String getdongcode(String dongname) throws SQLException;
	public String getdongname(String dongCode) throws SQLException;
	public void insertFavorite(UserFavoriteDto dto) throws SQLException;
	public void deleteFavorite(UserFavoriteDto dto) throws SQLException;
	public UserDto login(Map<String, String> map) throws SQLException;
	public String getpwd(String userid, String username) throws SQLException;
	public void deleteFavoriteAll(String userid) throws SQLException;
}
